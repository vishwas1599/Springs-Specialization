package com.th;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.th.controller.CustomerLoginController;
import com.th.dto.CustomerLoginDTO;

@SpringBootApplication
public class Demo1Application implements CommandLineRunner {

	@Autowired
	CustomerLoginController customerLoginController;
	
	@Autowired
	Environment environment;
	
	public static final Log LOGGER = LogFactory.getLog(Demo1Application.class);
	
	public static void main(String[] args) {
		
		SpringApplication.run(Demo1Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		try
		{CustomerLoginDTO customerLoginDTO = new CustomerLoginDTO();
		customerLoginDTO.setLoginName("harry");
		customerLoginDTO.setPassword("harry12");

		String message = customerLoginController.authenticateCustomer(customerLoginDTO);
		//System.out.println(message);
		LOGGER.info(environment.getProperty(message));
	} catch(Exception exception) {
		LOGGER.info(environment.getProperty(exception.getMessage()));
	}

	}
}
