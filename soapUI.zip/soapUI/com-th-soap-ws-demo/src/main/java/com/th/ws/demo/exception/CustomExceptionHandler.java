package com.th.ws.demo.exception;

public class CustomExceptionHandler {

}
